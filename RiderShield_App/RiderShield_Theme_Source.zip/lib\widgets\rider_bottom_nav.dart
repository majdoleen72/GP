
import 'package:flutter/material.dart';

/// RiderShield Dynamic Notched Navbar
///
/// Visible tabs:
/// Home      = 0
/// Emergency = 2
/// Connect   = 3
///
/// Reports (1) and Profile (4) are opened from the header.
class RiderBottomNav extends StatelessWidget {
  const RiderBottomNav({
    super.key,
    required this.selectedIndex,
    required this.onSelect,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelect;

  static const List<int> _pages = [0, 2, 3];

  static const List<String> _labels = [
    'Home',
    'Emergency',
    'Connect',
  ];

  static const List<IconData> _icons = [
    Icons.home_rounded,
    Icons.health_and_safety_outlined,
    Icons.bluetooth_rounded,
  ];

  static const List<Color> _colors = [
    Color(0xFF8ED5FF),
    Color(0xFFFF1680),
    Color(0xFFB59AFF),
  ];

  @override
  Widget build(BuildContext context) {
    final reduceMotion =
        MediaQuery.disableAnimationsOf(context);

    final selected = _pages.indexOf(selectedIndex);
    final target = selected < 0 ? 0 : selected;

    return SizedBox(
      height: 105,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final width = constraints.maxWidth;
          final cellWidth = width / _pages.length;
          final targetX = cellWidth * (target + 0.5);

          return TweenAnimationBuilder<double>(
            tween: Tween<double>(end: targetX),
            duration: reduceMotion
                ? Duration.zero
                : const Duration(milliseconds: 430),
            curve: Curves.easeInOutCubic,
            builder: (context, centerX, child) {
              final activeColor = _colors[target];

              return Stack(
                clipBehavior: Clip.none,
                children: [
                  // OPAQUE BAR + OPAQUE NOTCH BACKING
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: _NavbarPainter(
                          centerX: centerX,
                        ),
                      ),
                    ),
                  ),

                  // NAVIGATION ICONS
                  Positioned(
                    top: 38,
                    left: 0,
                    right: 0,
                    height: 67,
                    child: Row(
                      children: List.generate(
                        _pages.length,
                        (index) {
                          final isActive = index == target;

                          return Expanded(
                            child: Semantics(
                              button: true,
                              selected: selected == index,
                              label: '${_labels[index]} tab',
                              child: GestureDetector(
                                behavior: HitTestBehavior.opaque,
                                onTap: () =>
                                    onSelect(_pages[index]),
                                child: Center(
                                  child: isActive
                                      ? const SizedBox.shrink()
                                      : Icon(
                                          _icons[index],
                                          size: 25,
                                          color: const Color(
                                            0xFFABB3C1,
                                          ),
                                        ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),

                  // NEON GLOW
                  Positioned(
                    left: centerX - 43,
                    top: -5,
                    width: 86,
                    height: 86,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: activeColor.withValues(
                                alpha: 0.25,
                              ),
                              blurRadius: 30,
                              spreadRadius: 2,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // ACTIVE CIRCLE
                  Positioned(
                    left: centerX - 34,
                    top: 4,
                    width: 68,
                    height: 68,
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          color: const Color(0xFF121523),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: activeColor,
                            width: 3.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: activeColor.withValues(
                                alpha: 0.65,
                              ),
                              blurRadius: 19,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Icon(
                          _icons[target],
                          size: 29,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),

                  // ACTIVE LABEL
                  Positioned(
                    top: 79,
                    left: centerX - cellWidth / 2,
                    width: cellWidth,
                    child: IgnorePointer(
                      child: Text(
                        _labels[target],
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: activeColor,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w800,
                          shadows: [
                            Shadow(
                              color: activeColor.withValues(
                                alpha: 0.8,
                              ),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

// --------------------------------------------------
// NAVBAR GEOMETRY
// --------------------------------------------------

Path _createBaseBarPath(Size size) {
  const double barTop = 37;
  const double cornerRadius = 30;

  return Path()
    ..addRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(
          0,
          barTop,
          size.width,
          size.height - barTop,
        ),
        const Radius.circular(cornerRadius),
      ),
    );
}

Path _createNotchPath(double centerX) {
  return Path()
    ..addOval(
      Rect.fromCircle(
        center: Offset(centerX, 38),
        radius: 40,
      ),
    );
}

Path _createNavbarPath(Size size, double centerX) {
  final basePath = _createBaseBarPath(size);
  final notchPath = _createNotchPath(centerX);

  return Path.combine(
    PathOperation.difference,
    basePath,
    notchPath,
  );
}

// --------------------------------------------------
// CUSTOM NAVBAR PAINTER
// --------------------------------------------------

class _NavbarPainter extends CustomPainter {
  const _NavbarPainter({
    required this.centerX,
  });

  final double centerX;

  @override
  void paint(Canvas canvas, Size size) {
    final basePath = _createBaseBarPath(size);
    final notchPath = _createNotchPath(centerX);
    final barPath = _createNavbarPath(size, centerX);

    // 1. Paint only the bar silhouette.
    // No full-screen rectangular background.
    canvas.drawPath(
      basePath,
      Paint()
        ..color = const Color(0xFF1A1D2B)
        ..style = PaintingStyle.fill
        ..isAntiAlias = true,
    );

    // 2. Fill the moving notch with opaque dark navy.
    // Clipping keeps it strictly inside the bar.
    canvas.save();
    canvas.clipPath(basePath);

    canvas.drawPath(
      notchPath,
      Paint()
        ..color = const Color(0xFF121523)
        ..style = PaintingStyle.fill
        ..isAntiAlias = true,
    );

    canvas.restore();

    // 3. Draw the curved notch edge and bar outline.
    canvas.drawPath(
      barPath,
      Paint()
        ..color = const Color(0x554B5A70)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..isAntiAlias = true,
    );
  }

  @override
  bool shouldRepaint(covariant _NavbarPainter oldDelegate) {
    return oldDelegate.centerX != centerX;
  }
}

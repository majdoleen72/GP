
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:glbview/glbview.dart';

import '../app/app_scope.dart';
import '../app/app_state.dart';
import '../widgets/screen_parts.dart';
import '../widgets/soft_glass_card.dart';

// ======================================================
// RIDERSHIELD COLORS
// ======================================================

const Color _midnight = Color(0xFF071225);
const Color _deep = Color(0xFF0B1830);
const Color _surface = Color(0xFF142640);
const Color _accent = Color(0xFF9DD7FF);
const Color _electric = Color(0xFF69BFFF);
const Color _green = Color(0xFF63D8A0);

const int _delayStep = 1;
const int _confirmSeconds = 5;

// ======================================================
// HOME DASHBOARD
// ======================================================

class HomeDashboardScreen extends StatelessWidget {
  const HomeDashboardScreen({
    super.key,
    required this.openTab,
  });

  final ValueChanged<int> openTab;

  static const int _emergencyTab = 2;
  static const int _connectTab = 3;

  @override
  Widget build(BuildContext context) {
    final state = RiderScope.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        final screenHeight = constraints.maxHeight;
        final screenWidth = constraints.maxWidth;

        final horizontalPadding =
            screenWidth > 620 ? 34.0 : 20.0;

        final topHeight =
            (screenHeight * 0.55).clamp(330.0, 430.0);

        final helmetHeight =
            (screenHeight * 0.25).clamp(155.0, 215.0);

        return ListView(
          padding: EdgeInsets.zero,
          children: [
            // ==========================================
            // TRANSPARENT GLASS TOP SECTION
            // ==========================================

            _GlassTopSection(
              height: topHeight,
              horizontalPadding: horizontalPadding,
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: _ConnectionStatus(
                      connected: state.demoHelmetConnected,
                    ),
                  ),

                  const SizedBox(height: 4),

                  Expanded(
                    child: _HomeHelmet3D(
                      height: helmetHeight,
                    ),
                  ),

                  const SizedBox(height: 6),

                  const Text(
                    'RiderShield Helmet',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: inkWhite,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Text(
                    state.demoHelmetConnected
                        ? 'Your helmet is connected'
                        : 'Connect your helmet to get started',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFFD0E3F0),
                      fontSize: 12.5,
                    ),
                  ),

                  const SizedBox(height: 18),

                  SizedBox(
                    width: double.infinity,
                    height: 51,
                    child: FilledButton(
                      onPressed: () => openTab(_connectTab),
                      style: FilledButton.styleFrom(
                        backgroundColor: _accent,
                        foregroundColor: _deep,
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(16),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment:
                            MainAxisAlignment.center,
                        children: [
                          Icon(
                            state.demoHelmetConnected
                                ? Icons.settings_bluetooth_rounded
                                : Icons.bluetooth_searching_rounded,
                            size: 20,
                          ),
                          const SizedBox(width: 9),
                          Flexible(
                            child: Text(
                              state.demoHelmetConnected
                                  ? 'Manage Helmet Connection'
                                  : 'Connect Helmet to Get Started',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 13.5,
                              ),
                            ),
                          ),
                          const SizedBox(width: 7),
                          const Icon(
                            Icons.arrow_forward_rounded,
                            size: 18,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ==========================================
            // ORIGINAL BOTTOM SECTION
            // ==========================================

            Container(
              width: double.infinity,
              constraints: BoxConstraints(
                minHeight:
                    (screenHeight - topHeight).clamp(
                  205.0,
                  double.infinity,
                ),
              ),
              padding: EdgeInsets.fromLTRB(
                horizontalPadding,
                25,
                horizontalPadding,
                135,
              ),
              color: Colors.transparent,
              child: SizedBox(
                height: 155,
                child: Row(
                  crossAxisAlignment:
                      CrossAxisAlignment.stretch,
                  children: [
                    const Expanded(
                      child: _SosDelayCard(),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _sosCard(
                        context,
                        state.contacts,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ====================================================
  // SOS ACTION
  // ====================================================

  Future<void> _startSos(
    BuildContext context,
    List<EmergencyContact> contacts,
  ) async {
    if (contacts.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(
            'Add an emergency contact first.',
          ),
        ),
      );

      openTab(_emergencyTab);
      return;
    }

    final sendToAll = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _SosConfirmDialog(
        count: contacts.length,
      ),
    );

    if (sendToAll == null || !context.mounted) {
      return;
    }

    if (sendToAll) {
      _sendSos(context, contacts);
      return;
    }

    final chosen =
        await showModalBottomSheet<List<EmergencyContact>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFF173550),
      builder: (_) => _ContactPicker(
        contacts: contacts,
      ),
    );

    if (chosen == null ||
        chosen.isEmpty ||
        !context.mounted) {
      return;
    }

    _sendSos(context, chosen);
  }

  void _sendSos(
    BuildContext context,
    List<EmergencyContact> to,
  ) {
    final names =
        to.map((contact) => contact.name).join(', ');

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(
          'SOS request confirmed for ${to.length} contact(s): $names. Messages have not been sent.',
        ),
      ),
    );
  }

  // ====================================================
  // SOS CARD
  // ====================================================

  Widget _sosCard(
    BuildContext context,
    List<EmergencyContact> contacts,
  ) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _startSos(context, contacts),
        borderRadius: BorderRadius.circular(26),
        child: Ink(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFFE5484D),
                Color(0xFF9E2A2F),
              ],
            ),
          ),
          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    height: 40,
                    width: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withValues(
                        alpha: 0.20,
                      ),
                    ),
                    child: const Icon(
                      Icons.sos_rounded,
                      color: Colors.white,
                      size: 22,
                    ),
                  ),
                  const Spacer(),
                  const Icon(
                    Icons.north_east_rounded,
                    color: Colors.white70,
                    size: 17,
                  ),
                ],
              ),
              const Spacer(),
              const Text(
                'SOS',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 3),
              const Text(
                'Tap to start SOS',
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ======================================================
// GLASS TOP SECTION
// ======================================================

class _GlassTopSection extends StatelessWidget {
  const _GlassTopSection({
    required this.height,
    required this.horizontalPadding,
    required this.child,
  });

  final double height;
  final double horizontalPadding;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    const radius = BorderRadius.only(
      bottomLeft: Radius.circular(38),
      bottomRight: Radius.circular(38),
    );

    return Container(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          BoxShadow(
            color: _midnight.withValues(alpha: 0.32),
            blurRadius: 23,
            spreadRadius: -7,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: radius,
        child: BackdropFilter(
          filter: ImageFilter.blur(
            sigmaX: 14,
            sigmaY: 14,
          ),
          child: Container(
            width: double.infinity,
            height: height,
            decoration: BoxDecoration(
              borderRadius: radius,
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: const [
                  0.0,
                  0.48,
                  0.78,
                  1.0,
                ],
                colors: [
                  Colors.white.withValues(alpha: 0.055),
                  _electric.withValues(alpha: 0.025),
                  _surface.withValues(alpha: 0.045),
                  _midnight.withValues(alpha: 0.23),
                ],
              ),
              border: Border(
                bottom: BorderSide(
                  color: _midnight.withValues(alpha: 0.75),
                  width: 1.6,
                ),
              ),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Floating decoration behind the helmet
                const Positioned.fill(
                  child: IgnorePointer(
                    child: _FloatingGlassShapes(),
                  ),
                ),

                // Soft bottom glass edge
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  height: 34,
                  child: IgnorePointer(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            _deep.withValues(alpha: 0.10),
                            _midnight.withValues(alpha: 0.30),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.fromLTRB(
                    horizontalPadding,
                    10,
                    horizontalPadding,
                    30,
                  ),
                  child: child,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ======================================================
// FLOATING GLASS SHAPES
// ======================================================

class _FloatingGlassShapes extends StatefulWidget {
  const _FloatingGlassShapes();

  @override
  State<_FloatingGlassShapes> createState() =>
      _FloatingGlassShapesState();
}

class _FloatingGlassShapesState
    extends State<_FloatingGlassShapes>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 9),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        final t = _controller.value * math.pi * 2;

        return Stack(
          children: [
            Positioned(
              left: -18,
              top: 72 + math.sin(t) * 8,
              child: _glassShape(
                size: 58,
                circle: true,
              ),
            ),

            Positioned(
              right: 18,
              top: 105 + math.cos(t) * 9,
              child: Transform.rotate(
                angle: 0.20 + math.sin(t) * 0.09,
                child: _glassShape(
                  size: 43,
                  circle: false,
                ),
              ),
            ),

            Positioned(
              left: 42,
              top: 190 + math.cos(t) * 7,
              child: _glassShape(
                size: 23,
                circle: false,
              ),
            ),

            Positioned(
              right: 43,
              top: 215 + math.sin(t) * 6,
              child: _glassShape(
                size: 18,
                circle: true,
              ),
            ),

            Positioned(
              right: 90,
              top: 65 + math.sin(t) * 5,
              child: _glassShape(
                size: 12,
                circle: true,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _glassShape({
    required double size,
    required bool circle,
  }) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape:
            circle ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: circle
            ? null
            : BorderRadius.circular(size * 0.28),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withValues(alpha: 0.105),
            _electric.withValues(alpha: 0.025),
            _midnight.withValues(alpha: 0.045),
          ],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.15),
          width: 0.8,
        ),
        boxShadow: [
          BoxShadow(
            color: _midnight.withValues(alpha: 0.13),
            blurRadius: 12,
            offset: const Offset(0, 5),
          ),
        ],
      ),
    );
  }
}

// ======================================================
// CONNECTION STATUS
// ======================================================

class _ConnectionStatus extends StatelessWidget {
  const _ConnectionStatus({
    required this.connected,
  });

  final bool connected;

  @override
  Widget build(BuildContext context) {
    final color = connected ? _green : _accent;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 8,
      ),
      decoration: BoxDecoration(
        color: _deep.withValues(alpha: 0.75),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: color.withValues(alpha: 0.35),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            connected ? 'Connected' : 'Not connected',
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ======================================================
// 3D HELMET
// ======================================================

class _HomeHelmet3D extends StatelessWidget {
  const _HomeHelmet3D({
    required this.height,
  });

  final double height;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final modelSize =
            (constraints.maxWidth * 0.78)
                .clamp(180.0, 300.0);

        return Center(
          child: SizedBox(
            width: modelSize,
            height: height,
            child: GlbView.asset(
              'assets/images/helmet.glb',
              width: modelSize,
              height: height,
              autoRotate: true,
              autoRotateDegreesPerSecond: 18,
              gestures: GlbGesture.orbit,
              initialYaw: 35,
              initialPitch: 10,
              initialDistance: 2.9,
              glossy: true,
              placeholder: const Center(
                child: CircularProgressIndicator(
                  color: _accent,
                  strokeWidth: 2,
                ),
              ),
              errorBuilder: (context, error) {
                debugPrint(
                  'Home helmet 3D error: $error',
                );

                return const Center(
                  child: Text(
                    'Unable to load 3D helmet',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                    ),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }
}

// ======================================================
// SOS COUNTDOWN
// ======================================================

class _SosDelayCard extends StatefulWidget {
  const _SosDelayCard();

  @override
  State<_SosDelayCard> createState() =>
      _SosDelayCardState();
}

class _SosDelayCardState extends State<_SosDelayCard> {
  Widget _roundButton(
    IconData icon,
    VoidCallback? onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        height: 32,
        width: 32,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: onTap == null
              ? const Color(0xFFBFD7E9)
                  .withValues(alpha: 0.45)
              : const Color(0xFFBFD7E9),
        ),
        child: Icon(
          icon,
          size: 18,
          color: const Color(0xFF16364D),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SoftGlassCard(
      light: true,
      padding: const EdgeInsets.all(15),
      child: ValueListenableBuilder<int>(
        valueListenable: SosSettings.delaySeconds,
        builder: (context, seconds, _) {
          return Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.timer_outlined,
                    color: Color(0xFF16364D),
                    size: 24,
                  ),
                  const Spacer(),
                  _roundButton(
                    Icons.remove_rounded,
                    seconds > SosSettings.minDelay
                        ? () {
                            SosSettings
                                .delaySeconds.value =
                                seconds - _delayStep;
                          }
                        : null,
                  ),
                  const SizedBox(width: 6),
                  _roundButton(
                    Icons.add_rounded,
                    seconds < SosSettings.maxDelay
                        ? () {
                            SosSettings
                                .delaySeconds.value =
                                seconds + _delayStep;
                          }
                        : null,
                  ),
                ],
              ),
              const Spacer(),
              Row(
                crossAxisAlignment:
                    CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    '$seconds',
                    style: const TextStyle(
                      color: Color(0xFF143349),
                      fontSize: 34,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Text(
                    'sec',
                    style: TextStyle(
                      color: Color(0xFF416078),
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 3),
              const Text(
                'Set the SOS countdown',
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Color(0xFF597789),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ======================================================
// SOS CONFIRMATION
// ======================================================

class _SosConfirmDialog extends StatefulWidget {
  const _SosConfirmDialog({
    required this.count,
  });

  final int count;

  @override
  State<_SosConfirmDialog> createState() =>
      _SosConfirmDialogState();
}

class _SosConfirmDialogState
    extends State<_SosConfirmDialog> {
  int _left = _confirmSeconds;
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        if (_left <= 1) {
          timer.cancel();
          Navigator.of(context).pop(true);
        } else {
          setState(() {
            _left--;
          });
        }
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: _deep,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
      ),
      title: const Text(
        'Send SOS?',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w700,
        ),
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            'Do you accept to send an SOS to all your emergency contacts (${widget.count})?',
            style: const TextStyle(
              color: Color(0xFFD1DFEF),
              height: 1.4,
            ),
          ),
          const SizedBox(height: 14),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: _left / _confirmSeconds,
              minHeight: 6,
              color: const Color(0xFFE5484D),
              backgroundColor: Colors.white12,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'No answer? Sending to all in $_left s',
            style: const TextStyle(
              color: Color(0xFFBDE5FF),
              fontSize: 12.5,
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () =>
              Navigator.of(context).pop(false),
          child: const Text(
            'No, choose contacts',
            style: TextStyle(
              color: Color(0xFFBDE5FF),
            ),
          ),
        ),
        FilledButton(
          onPressed: () =>
              Navigator.of(context).pop(true),
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFFE5484D),
          ),
          child: const Text('Yes, send to all'),
        ),
      ],
    );
  }
}

// ======================================================
// CONTACT PICKER
// ======================================================

class _ContactPicker extends StatefulWidget {
  const _ContactPicker({
    required this.contacts,
  });

  final List<EmergencyContact> contacts;

  @override
  State<_ContactPicker> createState() =>
      _ContactPickerState();
}

class _ContactPickerState
    extends State<_ContactPicker> {
  final Set<String> _selected = {};

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(
          20,
          0,
          20,
          22,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'Choose who gets the SOS',
              style: TextStyle(
                color: inkWhite,
                fontSize: 21,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Select one or more emergency contacts.',
              style: TextStyle(
                color: softWhite,
                fontSize: 12.5,
              ),
            ),
            const SizedBox(height: 10),
            for (final contact in widget.contacts)
              CheckboxListTile(
                value: _selected.contains(contact.id),
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      _selected.add(contact.id);
                    } else {
                      _selected.remove(contact.id);
                    }
                  });
                },
                contentPadding: EdgeInsets.zero,
                controlAffinity:
                    ListTileControlAffinity.trailing,
                activeColor: const Color(0xFFE5484D),
                title: Text(
                  contact.name,
                  style: const TextStyle(
                    color: inkWhite,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                subtitle: Text(
                  '${contact.relationship} • ${contact.phone}',
                  style: const TextStyle(
                    color: softWhite,
                    fontSize: 12,
                  ),
                ),
              ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: FilledButton.icon(
                onPressed: _selected.isEmpty
                    ? null
                    : () {
                        Navigator.of(context).pop(
                          widget.contacts
                              .where(
                                (contact) =>
                                    _selected.contains(
                                  contact.id,
                                ),
                              )
                              .toList(),
                        );
                      },
                style: FilledButton.styleFrom(
                  backgroundColor:
                      const Color(0xFFE5484D),
                ),
                icon: const Icon(
                  Icons.sos_rounded,
                ),
                label: Text(
                  _selected.isEmpty
                      ? 'Select at least one contact'
                      : 'Send SOS to ${_selected.length}',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

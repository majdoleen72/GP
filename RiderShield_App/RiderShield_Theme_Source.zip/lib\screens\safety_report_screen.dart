import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../app/app_scope.dart';
import '../app/app_state.dart';
import '../widgets/screen_parts.dart';
import '../widgets/soft_glass_card.dart';

// NOTE: WarningEvent (in app_state.dart) has speedLevel, drowsinessLevel and
// proximityLevel ('High' / 'Medium' / 'Low' / null) and RiderState has addWarning.

class SafetyReportScreen extends StatefulWidget {
  const SafetyReportScreen({super.key, this.openProfile});
  final VoidCallback? openProfile;

  @override
  State<SafetyReportScreen> createState() => _SafetyReportScreenState();
}

class _SafetyReportScreenState extends State<SafetyReportScreen> {
  int _tab = 0;
  String? _filter;

  // Crash date-range filter
  DateTimeRange? _crashDateRange;
  int? _recentDays; // null = All, -1 = Custom

  bool _isInCrashDateRange(CrashIncident incident) {
    if (_recentDays == null) return true;
    if (_recentDays != -1) {
      final today = DateUtils.dateOnly(DateTime.now());
      final start = today.subtract(Duration(days: _recentDays! - 1));
      final end = today.add(const Duration(days: 1));
      return !incident.happenedAt.isBefore(start) &&
          incident.happenedAt.isBefore(end);
    }
    final range = _crashDateRange;
    if (range == null) return true;

    final date = incident.happenedAt;
    final start = DateUtils.dateOnly(range.start);
    final endExclusive =
        DateUtils.dateOnly(range.end).add(const Duration(days: 1));

    return !date.isBefore(start) && date.isBefore(endExclusive);
  }

  // Compact bottom sheet: presets and an inline calendar for custom dates.
  Future<void> _showCrashFilterSheet() async {
    final today = DateUtils.dateOnly(DateTime.now());
    int? draftDays = _recentDays;
    DateTime draftStart = _crashDateRange?.start ??
        today.subtract(const Duration(days: 29));
    DateTime draftEnd = _crashDateRange?.end ?? today;
    bool pickingStart = true;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFF142C43),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, updateSheet) {
          Widget option(String label, int? days) {
            final selected = draftDays == days;
            return InkWell(
              borderRadius: BorderRadius.circular(15),
              onTap: () => updateSheet(() => draftDays = days),
              child: Container(
                margin: const EdgeInsets.only(bottom: 7),
                padding: const EdgeInsets.symmetric(
                  horizontal: 15, vertical: 13,
                ),
                decoration: BoxDecoration(
                  color: selected
                      ? actionBlue.withValues(alpha: .17)
                      : Colors.white.withValues(alpha: .05),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: selected
                        ? actionBlue.withValues(alpha: .65)
                        : Colors.white.withValues(alpha: .08),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(label, style: TextStyle(
                        color: inkWhite,
                        fontWeight: selected
                            ? FontWeight.w700 : FontWeight.w500,
                      )),
                    ),
                    Icon(
                      selected ? Icons.check_circle_rounded
                          : Icons.circle_outlined,
                      color: selected ? actionBlue : softWhite,
                      size: 21,
                    ),
                  ],
                ),
              ),
            );
          }

          Widget dateButton(String label, DateTime date, bool isStart) {
            final active = pickingStart == isStart;
            return Expanded(
              child: OutlinedButton(
                onPressed: () => updateSheet(() => pickingStart = isStart),
                style: OutlinedButton.styleFrom(
                  foregroundColor: active ? actionBlue : inkWhite,
                  side: BorderSide(
                    color: active ? actionBlue : Colors.white24,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 13,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(13),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(label, style: const TextStyle(fontSize: 11)),
                    const SizedBox(height: 4),
                    Text(_formatRangeDate(date),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 12,
                        fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
            );
          }

          return SafeArea(
            top: false,
            child: FractionallySizedBox(
              heightFactor: .85,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Filter crash history', style: TextStyle(
                      color: inkWhite, fontSize: 21,
                      fontWeight: FontWeight.w800,
                    )),
                    const SizedBox(height: 5),
                    const Text('Choose a time period', style: TextStyle(
                      color: softWhite, fontSize: 12,
                    )),
                    const SizedBox(height: 16),
                    Expanded(
                      child: ListView(
                        children: [
                          option('All time', null),
                          option('Last 7 days', 7),
                          option('Last 30 days', 30),
                          option('Last 90 days', 90),
                          option('Custom dates', -1),
                          if (draftDays == -1) ...[
                            const SizedBox(height: 10),
                            Row(children: [
                              dateButton('From', draftStart, true),
                              const SizedBox(width: 10),
                              dateButton('To', draftEnd, false),
                            ]),
                            const SizedBox(height: 8),
                            Theme(
                              data: Theme.of(sheetContext).copyWith(
                                colorScheme: const ColorScheme.dark(
                                  primary: actionBlue,
                                  onPrimary: Color(0xFF0E2238),
                                  surface: Color(0xFF142C43),
                                  onSurface: inkWhite,
                                ),
                              ),
                              child: CalendarDatePicker(
                                key: ValueKey(pickingStart),
                                initialDate: pickingStart
                                    ? draftStart : draftEnd,
                                firstDate: DateTime(2000),
                                lastDate: today,
                                onDateChanged: (date) {
                                  updateSheet(() {
                                    if (pickingStart) {
                                      draftStart = date;
                                      if (draftEnd.isBefore(date)) {
                                        draftEnd = date;
                                      }
                                      pickingStart = false;
                                    } else {
                                      draftEnd = date;
                                      if (draftStart.isAfter(date)) {
                                        draftStart = date;
                                      }
                                    }
                                  });
                                },
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                          backgroundColor: actionBlue,
                          foregroundColor: const Color(0xFF0E2238),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        onPressed: () {
                          setState(() {
                            _recentDays = draftDays;
                            _crashDateRange = draftDays == -1
                                ? DateTimeRange(
                                    start: draftStart, end: draftEnd)
                                : null;
                          });
                          Navigator.pop(sheetContext);
                        },
                        child: const Text('Apply filter', style: TextStyle(
                          fontWeight: FontWeight.w800,
                        )),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _clearCrashDateRange() {
    setState(() {
      _crashDateRange = null;
      _recentDays = null;
    });
  }

  String _formatRangeDate(DateTime date) {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];

    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  // Location helpers
  bool _isMapLink(String location) => location.startsWith('http');

  String _placeLabel(String location) {
    if (!_isMapLink(location)) return location;
    final q = Uri.tryParse(location)?.queryParameters['q'];
    return q == null ? 'GPS location' : 'GPS: ${q.replaceAll(',', ', ')}';
  }

  Future<void> _openMap(BuildContext context, String link) async {
    final ok = await launchUrl(
      Uri.parse(link),
      mode: LaunchMode.externalApplication,
    );

    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Maps.')),
      );
    }
  }

  // Crashes are classified by the SOS emergency request.
  bool _sosAccepted(CrashIncident incident) {
    final status = incident.notificationStatus
        .toLowerCase()
        .replaceAll('_', ' ')
        .trim();
    return status.startsWith('accept');
  }

  String _sosLabel(bool accepted) =>
      accepted ? 'SOS sent' : 'SOS not sent';

  Color _sosColor(bool accepted) => accepted
      ? const Color(0xFFFF6B72)
      : const Color(0xFF8ED5FF);

  String _statusLabel(String raw) {
    if (raw.isEmpty) return 'Unknown';

    final spaced = raw
        .replaceAllMapped(
          RegExp(r'([a-z])([A-Z])'),
          (m) => '${m[1]} ${m[2]}',
        )
        .replaceAll('_', ' ');

    return spaced[0].toUpperCase() + spaced.substring(1);
  }

  Widget _chip(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .16),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withValues(alpha: .45)),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
        ),
      );

  Widget _detailRow(IconData icon, String label, String value) =>
      Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .07),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withValues(alpha: .10)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 20, color: actionBlue),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      color: softWhite,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    value,
                    style: const TextStyle(
                      color: inkWhite,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  // ---------- Accident details ----------

  void showIncident(BuildContext context, CrashIncident incident) {
    final state = RiderScope.of(context);
    final accepted = _sosAccepted(incident);
    final color = _sosColor(accepted);

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF173550),
      builder: (sheet) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 26),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withValues(alpha: .18),
                    ),
                    child: Icon(
                      Icons.car_crash_outlined,
                      color: color,
                      size: 27,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          incident.testOnly
                              ? 'Test crash'
                              : 'Crash incident',
                          style: const TextStyle(
                            color: inkWhite,
                            fontSize: 21,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        _chip(_sosLabel(accepted), color),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _detailRow(
                Icons.event_rounded,
                'Date & time',
                prettyDate(incident.happenedAt),
              ),
              _detailRow(
                Icons.place_outlined,
                'Location',
                _placeLabel(incident.location),
              ),
              _detailRow(
                Icons.notifications_active_outlined,
                'Emergency request',
                accepted
                    ? 'Sent'
                    : (_statusLabel(incident.notificationStatus) == 'Not sent'
                        ? 'Not sent'
                        : 'Not sent (${_statusLabel(incident.notificationStatus)})'),
              ),
              if (incident.testOnly) ...[
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      Navigator.pop(sheet);
                      await state.removeIncident(incident.id);
                    },
                    icon: const Icon(Icons.delete_outline_rounded),
                    label: const Text('Delete incident'),
                  ),
                ),
              ],
              if (_isMapLink(incident.location)) ...[
                const SizedBox(height: 6),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton.icon(
                    onPressed: () => _openMap(context, incident.location),
                    icon: const Icon(Icons.map_rounded),
                    label: const Text('Open in Maps'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ---------- Accident card ----------

  Widget _incidentCard(
    BuildContext context,
    CrashIncident incident,
  ) {
    final accepted = _sosAccepted(incident);
    final color = _sosColor(accepted);

    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: SoftGlassCard(
        onTap: () => showIncident(context, incident),
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: color.withValues(alpha: .16),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(
                Icons.warning_amber_rounded,
                color: color,
                size: 25,
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Crash detected',
                          style: TextStyle(
                            color: inkWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      _chip(_sosLabel(accepted), color),
                    ],
                  ),
                  const SizedBox(height: 7),
                  Row(
                    children: [
                      const Icon(
                        Icons.schedule_rounded,
                        size: 14,
                        color: softWhite,
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          prettyDate(incident.happenedAt),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: softWhite,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(
                        Icons.place_outlined,
                        size: 14,
                        color: softWhite,
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          _placeLabel(incident.location),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: softWhite,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Icon(
              Icons.chevron_right_rounded,
              color: softWhite,
            ),
          ],
        ),
      ),
    );
  }

  // ---------- Report overview ----------

  Widget _heroStat(
    IconData icon,
    String label,
    String value,
    Color color,
  ) =>
      Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 11,
            vertical: 12,
          ),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: .09),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: Colors.white.withValues(alpha: .12),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 18, color: color),
              const SizedBox(height: 9),
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: inkWhite,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: softWhite,
                  fontSize: 10.5,
                ),
              ),
            ],
          ),
        ),
      );

  Widget _hero(
    List<CrashIncident> incidents,
    int warningCount,
  ) {
    final clear = incidents.isEmpty;
    final accent = clear
        ? const Color(0xFF7BE0AE)
        : const Color(0xFFFFA45C);

    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    ];

    final last = clear
        ? 'None'
        : '${incidents.first.happenedAt.day} '
            '${months[incidents.first.happenedAt.month - 1]}';

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF1E4E78),
            Color(0xFF14304D),
            Color(0xFF0E2238),
          ],
        ),
        border: Border.all(
          color: Colors.white.withValues(alpha: .14),
        ),
        boxShadow: const [
          BoxShadow(
            color: Color(0x40000000),
            blurRadius: 22,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withValues(alpha: .18),
                  border: Border.all(
                    color: accent.withValues(alpha: .55),
                    width: 2,
                  ),
                ),
                child: Icon(
                  clear
                      ? Icons.verified_user_rounded
                      : Icons.shield_moon_rounded,
                  color: accent,
                  size: 28,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Safety Report',
                      style: TextStyle(
                        color: inkWhite,
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -.4,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      clear
                          ? 'All clear — no crashes recorded'
                          : 'Crash and warning records',
                      style: TextStyle(
                        color: accent,
                        fontSize: 12.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _heroStat(
                Icons.car_crash_outlined,
                'Total crashes',
                '${incidents.length}',
                const Color(0xFFFF8993),
              ),
              const SizedBox(width: 10),
              _heroStat(
                Icons.schedule_rounded,
                'Last crash',
                last,
                const Color(0xFF8ED5FF),
              ),
              const SizedBox(width: 10),
              _heroStat(
                Icons.warning_amber_rounded,
                'Warnings',
                '$warningCount',
                const Color(0xFFFFB45C),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ---------- Warning history ----------

  (IconData, String, Color) _warningMeta(WarningType type) =>
      switch (type) {
        WarningType.speed => (
            Icons.speed_rounded,
            'Speed warning',
            const Color(0xFFFFB45C),
          ),
        WarningType.drowsiness => (
            Icons.bedtime_outlined,
            'Drowsiness',
            const Color(0xFFB99BFF),
          ),
        WarningType.vehicleProximity => (
            Icons.directions_car_filled_outlined,
            'Vehicle too close',
            const Color(0xFFFF8993),
          ),
      };

  // ---------- Warning level ----------

  (String?, String?, String?) _factors(WarningEvent w) {
    if (w.speedLevel == null &&
        w.drowsinessLevel == null &&
        w.proximityLevel == null) {
      return (
        w.type == WarningType.speed ? 'Low' : null,
        w.type == WarningType.drowsiness ? 'Low' : null,
        w.type == WarningType.vehicleProximity ? 'Low' : null,
      );
    }
    return (w.speedLevel, w.drowsinessLevel, w.proximityLevel);
  }

  int _rank(String? level) => switch (level) {
        'High' => 3,
        'Medium' => 2,
        'Low' => 1,
        _ => 0,
      };

  String _warningLevel(WarningEvent w) {
    final (s, d, p) = _factors(w);
    final top = [s, d, p].map(_rank).reduce((a, b) => a > b ? a : b);
    return switch (top) {
      3 => 'High',
      2 => 'Medium',
      _ => 'Low',
    };
  }

  // Only High and Medium warnings are shown.
  List<WarningEvent> _shownWarnings(RiderState state) =>
      state.warnings.where((w) => _warningLevel(w) != 'Low').toList();

  Color _warningLevelColor(String level) => switch (level) {
        'High' => const Color(0xFFFF6B72),
        'Medium' => const Color(0xFFFFB45C),
        _ => const Color(0xFF7BE0AE),
      };

  Widget _factorRow(IconData icon, String label, String? level) {
    final active = level != null;
    final color = level == null ? softWhite : _warningLevelColor(level);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: active
            ? color.withValues(alpha: .12)
            : Colors.white.withValues(alpha: .06),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: active
              ? color.withValues(alpha: .5)
              : Colors.white.withValues(alpha: .10),
        ),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: inkWhite,
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          _chip(level ?? 'Normal', color),
        ],
      ),
    );
  }

  // ---------- Crashes / warnings tabs ----------

  Widget _segmented(int crashes, int warnings) {
    Widget option(
      int index,
      IconData icon,
      String label,
      int count,
      Color color,
    ) {
      final selected = _tab == index;

      return Expanded(
        child: InkWell(
          onTap: () => setState(() => _tab = index),
          borderRadius: BorderRadius.circular(16),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              color: selected
                  ? color.withValues(alpha: .20)
                  : Colors.transparent,
              border: Border.all(
                color: selected
                    ? color.withValues(alpha: .7)
                    : Colors.transparent,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  size: 18,
                  color: selected ? color : softWhite,
                ),
                const SizedBox(width: 7),
                Text(
                  '$label ($count)',
                  style: TextStyle(
                    color: selected ? inkWhite : softWhite,
                    fontSize: 13.5,
                    fontWeight:
                        selected ? FontWeight.w800 : FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .07),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withValues(alpha: .10),
        ),
      ),
      child: Row(
        children: [
          option(
            0,
            Icons.car_crash_outlined,
            'Crashes',
            crashes,
            const Color(0xFFFF8993),
          ),
          option(
            1,
            Icons.warning_amber_rounded,
            'Warnings',
            warnings,
            const Color(0xFFFFB45C),
          ),
        ],
      ),
    );
  }

  // ---------- Warning card ----------

  // Numerical measurements are intentionally hidden.
  Widget _warningCard(BuildContext context, WarningEvent w) {
    final level = _warningLevel(w);
    final color = _warningLevelColor(level);

    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: SoftGlassCard(
        onTap: () => showWarning(context, w),
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: color.withValues(alpha: .16),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Icon(
                Icons.warning_amber_rounded,
                color: color,
                size: 25,
              ),
            ),
            const SizedBox(width: 13),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Warning detected',
                          style: TextStyle(
                            color: inkWhite,
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      _chip(level, color),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      const Icon(
                        Icons.schedule_rounded,
                        size: 14,
                        color: softWhite,
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          prettyDate(w.happenedAt),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: softWhite,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            const Icon(
              Icons.chevron_right_rounded,
              color: softWhite,
            ),
          ],
        ),
      ),
    );
  }

  // ---------- Warning details ----------

  void showWarning(BuildContext context, WarningEvent w) {
    final (icon, label, color) = _warningMeta(w.type);
    final level = _warningLevel(w);
    final levelColor = _warningLevelColor(level);
    final (fs, fd, fp) = _factors(w);

    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF173550),
      builder: (sheet) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 26),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: color.withValues(alpha: .18),
                    ),
                    child: Icon(
                      icon,
                      color: color,
                      size: 27,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          label,
                          style: const TextStyle(
                            color: inkWhite,
                            fontSize: 21,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        _chip('$level warning', levelColor),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              _detailRow(
                Icons.event_rounded,
                'Date & time',
                prettyDate(w.happenedAt),
              ),
              const SizedBox(height: 6),
              const Text(
                'Trigger factors',
                style: TextStyle(
                  color: softWhite,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              _factorRow(Icons.speed_rounded, 'Speed', fs),
              _factorRow(Icons.bedtime_outlined, 'Drowsiness', fd),
              _factorRow(
                Icons.directions_car_filled_outlined,
                'Vehicle proximity',
                fp,
              ),
              const SizedBox(height: 4),
              _detailRow(
                Icons.rule_rounded,
                'Overall level',
                level,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------- Clear warning history ----------

  Future<void> _confirmClear(BuildContext context) async {
    final state = RiderScope.of(context);

    final ok = await showDialog<bool>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: const Text('Clear warning history?'),
        content: const Text(
          'All recorded warnings will be removed.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialog, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialog, true),
            child: const Text('Clear'),
          ),
        ],
      ),
    );

    if (ok == true) {
      await state.clearWarnings();
    }
  }

  // ---------- Crash history ----------

  Widget _crashFilterButton() {
    final custom = _recentDays == -1 && _crashDateRange != null;
    final label = custom
        ? 'Custom range'
        : switch (_recentDays) {
            7 => 'Last 7 days',
            30 => 'Last 30 days',
            90 => 'Last 90 days',
            _ => 'All',
          };

    return InkWell(
      onTap: _showCrashFilterSheet,
      borderRadius: BorderRadius.circular(13),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: Colors.white.withValues(alpha: .16)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.tune_rounded, color: actionBlue, size: 17),
          const SizedBox(width: 6),
          Flexible(child: Text(label,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: inkWhite, fontSize: 11,
              fontWeight: FontWeight.w600))),
          const SizedBox(width: 3),
          const Icon(Icons.keyboard_arrow_down_rounded,
            color: softWhite, size: 16),
        ]),
      ),
    );
  }

  Future<void> _showWarningFilterSheet(int total, int high, int medium) async {
    String? draft = _filter;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      backgroundColor: const Color(0xFF142C43),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, updateSheet) => SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Filter warning history', style: TextStyle(
                  color: inkWhite, fontSize: 21, fontWeight: FontWeight.w800,
                )),
                const SizedBox(height: 5),
                const Text('Choose a warning level', style: TextStyle(
                  color: softWhite, fontSize: 12,
                )),
                const SizedBox(height: 16),
                for (final option in <(String, String?, int)>[
                  ('All warnings', null, total),
                  ('High', 'High', high),
                  ('Medium', 'Medium', medium),
                ])
                  InkWell(
                    onTap: () => updateSheet(() => draft = option.$2),
                    borderRadius: BorderRadius.circular(15),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 14,
                      ),
                      decoration: BoxDecoration(
                        color: draft == option.$2
                            ? actionBlue.withValues(alpha: .17)
                            : Colors.white.withValues(alpha: .05),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(
                          color: draft == option.$2
                              ? actionBlue.withValues(alpha: .65)
                              : Colors.white.withValues(alpha: .08),
                        ),
                      ),
                      child: Row(children: [
                        Expanded(child: Text('${option.$1} (${option.$3})',
                          style: const TextStyle(color: inkWhite,
                            fontWeight: FontWeight.w600))),
                        Icon(draft == option.$2
                            ? Icons.check_circle_rounded
                            : Icons.circle_outlined,
                          color: draft == option.$2 ? actionBlue : softWhite,
                          size: 21),
                      ]),
                    ),
                  ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: actionBlue,
                      foregroundColor: const Color(0xFF0E2238),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    onPressed: () {
                      setState(() => _filter = draft);
                      Navigator.pop(sheetContext);
                    },
                    child: const Text('Apply filter',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _warningFilterButton(int total, int high, int medium) {
    final label = _filter ?? 'All';
    return InkWell(
      onTap: () => _showWarningFilterSheet(total, high, medium),
      borderRadius: BorderRadius.circular(13),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: Colors.white.withValues(alpha: .16)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.tune_rounded, color: actionBlue, size: 17),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: inkWhite, fontSize: 11,
              fontWeight: FontWeight.w600)),
          const SizedBox(width: 3),
          const Icon(Icons.keyboard_arrow_down_rounded,
              color: softWhite, size: 16),
        ]),
      ),
    );
  }

  List<Widget> _crashSection(
    BuildContext context,
    RiderState state,
  ) {
    final all = state.incidents;
    final shown = all.where(_isInCrashDateRange).toList();

    return [
      SectionCaption('Crash history', trailing: _crashFilterButton()),
      if (_recentDays == -1 && _crashDateRange != null)
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text(
            '${_formatRangeDate(_crashDateRange!.start)} – ${_formatRangeDate(_crashDateRange!.end)}',
            style: const TextStyle(color: softWhite, fontSize: 12),
          ),
        ),

      if (shown.isEmpty)
        SoftGlassCard(
          padding: const EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 26,
          ),
          child: Column(
            children: [
              Icon(
                all.isEmpty
                    ? Icons.verified_user_outlined
                    : Icons.calendar_month_outlined,
                color: actionBlue,
                size: 42,
              ),
              const SizedBox(height: 12),
              Text(
                all.isEmpty
                    ? 'No crashes recorded'
                    : 'No crashes in this date range',
                style: const TextStyle(
                  color: inkWhite,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 7),
              Text(
                all.isEmpty
                    ? 'Crashes detected during your rides will appear here.'
                    : 'Try selecting another date range or reset the filter to see all crash reports.',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: softWhite,
                  height: 1.4,
                ),
              ),
              if (all.isNotEmpty && _crashDateRange != null) ...[
                const SizedBox(height: 14),
                TextButton.icon(
                  onPressed: _clearCrashDateRange,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Show all crash reports'),
                  style: TextButton.styleFrom(
                    foregroundColor: actionBlue,
                  ),
                ),
              ],
            ],
          ),
        ),

      for (final incident in shown)
        _incidentCard(context, incident),
    ];
  }

  // ---------- Warning history section ----------

  List<Widget> _warningSection(
    BuildContext context,
    RiderState state,
  ) {
    final all = _shownWarnings(state);

    final shown = _filter == null
        ? all
        : all.where((w) => _warningLevel(w) == _filter).toList();

    int count(String level) =>
        all.where((w) => _warningLevel(w) == level).length;

    return [
      SectionCaption(
        'Warning history',
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _warningFilterButton(all.length, count('High'), count('Medium')),
            if (all.isNotEmpty) ...[
              const SizedBox(width: 4),
              TextButton(
                onPressed: () => _confirmClear(context),
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFFFF8F8F),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  minimumSize: const Size(0, 36),
                ),
                child: const Text('Clear all', style: TextStyle(fontSize: 11)),
              ),
            ],
          ],
        ),
      ),
      const SizedBox(height: 8),
      if (shown.isEmpty)
        const SoftGlassCard(
          padding: EdgeInsets.symmetric(
            horizontal: 18,
            vertical: 26,
          ),
          child: Column(
            children: [
              Icon(
                Icons.shield_outlined,
                color: actionBlue,
                size: 42,
              ),
              SizedBox(height: 12),
              Text(
                'No warnings recorded',
                style: TextStyle(
                  color: inkWhite,
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 7),
              Text(
                'Warnings detected during your rides will appear here.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: softWhite,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      for (final w in shown)
        _warningCard(context, w),
    ];
  }

  // ---------- Main screen ----------

  @override
  Widget build(BuildContext context) {
    final state = RiderScope.of(context);
    final warningCount = _shownWarnings(state).length;

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
      children: [
        _hero(state.incidents, warningCount),
        const SizedBox(height: 18),
        _segmented(
          state.incidents.length,
          warningCount,
        ),
        const SizedBox(height: 20),
        if (_tab == 0)
          ..._crashSection(context, state)
        else
          ..._warningSection(context, state),
      ],
    );
  }
}
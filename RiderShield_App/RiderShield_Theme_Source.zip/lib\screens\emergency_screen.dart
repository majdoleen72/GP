
import 'package:flutter/material.dart';

import '../app/app_scope.dart';
import '../app/app_state.dart';
import '../widgets/screen_parts.dart';
import '../widgets/soft_glass_card.dart';
import '../widgets/apple_grouped_fields.dart';

class EmergencyScreen extends StatelessWidget {
  const EmergencyScreen({
    super.key,
    this.openProfile,
  });

  final VoidCallback? openProfile;

  static const _avatarColors = [
    Color(0xFF5CB6F0),
    Color(0xFF7BE0AE),
    Color(0xFFFFB45C),
    Color(0xFFB99BFF),
    Color(0xFFFF8FA3),
  ];

  // ------------------------------------------
  // ADD / EDIT EMERGENCY CONTACT
  // ------------------------------------------

  Future<void> editContact(
    BuildContext context, {
    EmergencyContact? existing,
  }) async {
    final state = RiderScope.of(context);

    final key = GlobalKey<FormState>();

    final name = TextEditingController(
      text: existing?.name ?? '',
    );

    final phone = TextEditingController(
      text: existing?.phone ?? '',
    );

    final relationship = TextEditingController(
      text: existing?.relationship ?? '',
    );

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFF173550),
      builder: (sheet) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          0,
          20,
          MediaQuery.viewInsetsOf(sheet).bottom + 22,
        ),
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            child: Form(
              key: key,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    existing == null
                        ? 'Add emergency contact'
                        : 'Edit contact',
                    style: const TextStyle(
                      fontSize: 23,
                      fontWeight: FontWeight.w700,
                    ),
                  ),

                  const SizedBox(height: 18),

                  AppleFormGroup(
                    children: [
                      AppleFormField(
                        label: 'Name',
                        controller: name,
                        hint: 'Full name',
                        icon: Icons.person_outline_rounded,
                        validator: (v) =>
                            (v ?? '').trim().isEmpty
                                ? 'Enter a name'
                                : null,
                      ),

                      AppleFormField(
                        label: 'Relation',
                        controller: relationship,
                        hint: 'e.g. Sister',
                        icon: Icons.group_outlined,
                        validator: (v) =>
                            (v ?? '').trim().isEmpty
                                ? 'Enter relationship'
                                : null,
                      ),

                      AppleFormField(
                        label: 'Phone',
                        controller: phone,
                        hint: '+9665...',
                        icon: Icons.phone_outlined,
                        keyboardType: TextInputType.phone,
                        textInputAction: TextInputAction.done,
                        validator: (v) => RegExp(
                          r'^\+?[0-9 ()-]{7,20}$',
                        ).hasMatch((v ?? '').trim())
                            ? null
                            : 'Enter a valid phone number',
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),

                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: FilledButton(
                      onPressed: () async {
                        if (!(key.currentState?.validate() ??
                            false)) {
                          return;
                        }

                        final saving = state.upsertContact(
                          EmergencyContact(
                            id: existing?.id ??
                                DateTime.now()
                                    .microsecondsSinceEpoch
                                    .toString(),
                            name: name.text.trim(),
                            relationship:
                                relationship.text.trim(),
                            phone: phone.text.trim(),
                          ),
                        );

                        if (sheet.mounted) {
                          Navigator.pop(sheet);
                        }

                        await saving;
                      },
                      child: const Text('Save contact'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );

    // Wait for the sheet closing animation before disposal.
    Future.delayed(
      const Duration(milliseconds: 500),
      () {
        name.dispose();
        phone.dispose();
        relationship.dispose();
      },
    );
  }

  // ------------------------------------------
  // DELETE EMERGENCY CONTACT
  // ------------------------------------------

  Future<void> deleteContact(
    BuildContext context,
    EmergencyContact contact,
  ) async {
    final state = RiderScope.of(context);

    final remove = await showDialog<bool>(
      context: context,
      builder: (dialog) => AlertDialog(
        title: const Text('Delete contact?'),
        content: Text(
          'Remove ${contact.name} from your emergency contacts?',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(dialog, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () =>
                Navigator.pop(dialog, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (remove == true) {
      await state.deleteContact(contact.id);
    }
  }

  // ------------------------------------------
  // ORIGINAL EMERGENCY SOS CARD
  // ------------------------------------------

  // Informational card only.
  // SOS is triggered by crash detection.
  Widget _sosHero() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(30),
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFFE5484D),
          Color(0xFFB02A3A),
          Color(0xFF6E1B33),
        ],
      ),
      boxShadow: const [
        BoxShadow(
          color: Color(0x55E5484D),
          blurRadius: 26,
          offset: Offset(0, 12),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 58,
              height: 58,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white.withValues(
                  alpha: 0.20,
                ),
                border: Border.all(
                  color: Colors.white.withValues(
                    alpha: 0.5,
                  ),
                  width: 2,
                ),
              ),
              child: const Icon(
                Icons.sos_rounded,
                color: Colors.white,
                size: 32,
              ),
            ),

            const SizedBox(width: 14),

            const Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    'Emergency SOS',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 23,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -0.3,
                    ),
                  ),

                  SizedBox(height: 3),

                  Text(
                    'Your contacts are alerted after a detected crash.',
                    style: TextStyle(
                      color: Color(0xFFFFD6D8),
                      fontSize: 12.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ],
    ),
  );

  // ------------------------------------------
  // CONTACT ACTION BUTTON
  // ------------------------------------------

  Widget _iconAction(
    IconData icon,
    Color color,
    String tooltip,
    VoidCallback onTap,
  ) =>
      Tooltip(
        message: tooltip,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              icon,
              size: 19,
              color: color,
            ),
          ),
        ),
      );

  // ------------------------------------------
  // EMERGENCY CONTACT CARD
  // ------------------------------------------

  Widget _contactCard(
    BuildContext context,
    EmergencyContact contact,
    int index,
  ) {
    final color =
        _avatarColors[index % _avatarColors.length];

    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: SoftGlassCard(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withValues(alpha: 0.20),
                border: Border.all(
                  color: color.withValues(alpha: 0.6),
                  width: 2,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                contact.name.isEmpty
                    ? '?'
                    : contact.name[0].toUpperCase(),
                style: TextStyle(
                  color: color,
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),

            const SizedBox(width: 13),

            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    contact.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: inkWhite,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),

                  const SizedBox(height: 5),

                  Container(
                    padding:
                        const EdgeInsets.symmetric(
                      horizontal: 9,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: color.withValues(
                        alpha: 0.16,
                      ),
                      borderRadius:
                          BorderRadius.circular(20),
                    ),
                    child: Text(
                      contact.relationship,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: color,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),

                  const SizedBox(height: 6),

                  Row(
                    children: [
                      const Icon(
                        Icons.phone_outlined,
                        size: 13,
                        color: softWhite,
                      ),
                      const SizedBox(width: 5),
                      Expanded(
                        child: Text(
                          contact.phone,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: softWhite,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(width: 8),

            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _iconAction(
                  Icons.edit_outlined,
                  actionBlue,
                  'Edit ${contact.name}',
                  () => editContact(
                    context,
                    existing: contact,
                  ),
                ),

                const SizedBox(height: 8),

                _iconAction(
                  Icons.delete_outline_rounded,
                  const Color(0xFFFF8F8F),
                  'Delete ${contact.name}',
                  () => deleteContact(
                    context,
                    contact,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------
  // MAIN SCREEN
  // ------------------------------------------

  @override
  Widget build(BuildContext context) {
    final state = RiderScope.of(context);
    final contacts = state.contacts;

    return ListView(
      padding: const EdgeInsets.fromLTRB(
        20,
        18,
        20,
        135,
      ),
      children: [
        _sosHero(),

        const SizedBox(height: 24),

        SectionCaption(
          'Emergency contacts',
          trailing: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 4,
            ),
            decoration: BoxDecoration(
              color: actionBlue.withValues(
                alpha: 0.16,
              ),
              borderRadius:
                  BorderRadius.circular(20),
            ),
            child: Text(
              '${contacts.length} saved',
              style: const TextStyle(
                color: actionBlue,
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ),

        if (contacts.isEmpty)
          SoftGlassCard(
            padding: const EdgeInsets.symmetric(
              horizontal: 18,
              vertical: 28,
            ),
            child: Column(
              children: [
                Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: actionBlue.withValues(
                      alpha: 0.15,
                    ),
                  ),
                  child: const Icon(
                    Icons.groups_2_outlined,
                    size: 32,
                    color: actionBlue,
                  ),
                ),

                const SizedBox(height: 14),

                const Text(
                  'No contacts yet',
                  style: TextStyle(
                    color: inkWhite,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),

                const SizedBox(height: 6),

                const Text(
                  'Add a trusted person to your emergency list.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: softWhite,
                  ),
                ),
              ],
            ),
          ),

        for (var i = 0; i < contacts.length; i++)
          _contactCard(
            context,
            contacts[i],
            i,
          ),

        const SizedBox(height: 6),

        SizedBox(
          width: double.infinity,
          height: 54,
          child: FilledButton.tonalIcon(
            onPressed: () => editContact(context),
            style: FilledButton.styleFrom(
              backgroundColor:
                  actionBlue.withValues(alpha: 0.16),
              foregroundColor: actionBlue,
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(18),
              ),
              textStyle: const TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            icon: const Icon(
              Icons.person_add_alt_1_rounded,
            ),
            label: const Text('Add contact'),
          ),
        ),
      ],
    );
  }
}
